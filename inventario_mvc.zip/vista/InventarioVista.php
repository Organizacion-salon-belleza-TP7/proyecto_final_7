
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Inventario</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800 p-6">
  <h1 class="text-3xl font-bold mb-6">Inventario</h1>

  <form method="GET" class="mb-4 flex gap-2">
    <input type="text" name="buscar" placeholder="Buscar por nombre..." class="p-2 border rounded w-64" value="<?= htmlspecialchars($_GET['buscar'] ?? '') ?>">
    <button class="bg-blue-600 text-white px-4 rounded">Buscar</button>
    <a href="index.php" class="bg-gray-300 px-4 py-2 rounded text-black">Limpiar</a>
  </form>

  <form method="POST" enctype="multipart/form-data" class="mb-6 bg-white p-6 rounded shadow grid gap-4">
    <input type="hidden" name="id" value="<?= $_GET['editar'] ?? '' ?>">
    <input type="hidden" name="accion" value="<?= isset($_GET['editar']) ? 'modificar' : 'agregar' ?>">
    <input type="hidden" name="imagen_existente" value="<?= $producto['imagen_producto'] ?? '' ?>">

    <input name="nombre" required placeholder="Nombre del producto" class="p-2 border rounded" value="<?= $producto['nombre_producto'] ?? '' ?>">
    <input name="stock" type="number" required placeholder="Stock" class="p-2 border rounded" value="<?= $producto['stock'] ?? '' ?>">
    <input name="vencimiento" type="date" required class="p-2 border rounded" value="<?= $producto['vencimiento'] ?? '' ?>">
    <input name="precio_producto" type="number" step="0.01" required placeholder="Precio compra" class="p-2 border rounded" value="<?= $producto['precio_producto'] ?? '' ?>">
    <input name="precio_venta" type="number" step="0.01" required placeholder="Precio venta" class="p-2 border rounded" value="<?= $producto['precio_venta'] ?? '' ?>">
    <input name="proveedor" type="number" required placeholder="ID Proveedor" class="p-2 border rounded" value="<?= $producto['id_proveedor'] ?? '' ?>">
    <input type="file" name="imagen" class="p-2 border rounded">

    <button class="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 w-fit"><?= isset($_GET['editar']) ? 'Modificar' : 'Agregar' ?></button>
  </form>

  <table class="w-full bg-white rounded shadow text-sm">
    <thead class="bg-gray-100">
      <tr>
        <th class="p-2">ID</th>
        <th>Nombre</th>
        <th>Stock</th>
        <th>Vencimiento</th>
        <th>Precio Compra</th>
        <th>Precio Venta</th>
        <th>Imagen</th>
        <th>Proveedor</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($inventario as $item): ?>
      <tr class="border-t hover:bg-gray-50">
        <td class="text-center"><?= $item['id_inventario'] ?></td>
        <td><?= $item['nombre_producto'] ?></td>
        <td><?= $item['stock'] ?></td>
        <td><?= $item['vencimiento'] ?></td>
        <td>$<?= $item['precio_producto'] ?></td>
        <td>$<?= $item['precio_venta'] ?></td>
        <td>
          <?php if (!empty($item['imagen_producto'])): ?>
            <img src="<?= $item['imagen_producto'] ?>" width="50">
          <?php else: ?>
            Sin imagen
          <?php endif; ?>
        </td>
        <td><?= $item['id_proveedor'] ?></td>
        <td class="flex gap-2">
          <a href="?editar=<?= $item['id_inventario'] ?>" class="text-blue-600 hover:underline">Editar</a>
          <form method="POST" onsubmit="return confirm('¿Eliminar este producto?')">
            <input type="hidden" name="id" value="<?= $item['id_inventario'] ?>">
            <input type="hidden" name="accion" value="eliminar">
            <button class="text-red-600 hover:underline">Eliminar</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</body>
</html>
