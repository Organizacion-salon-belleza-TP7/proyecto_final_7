
<?php
require_once("controlador/InventarioControlador.php");

if (isset($_GET['editar'])) {
    $producto = $modelo->obtener($_GET['editar']);
}

include("vista/InventarioVista.php");
